export interface Icalculatorgoal{
    name:string,
    gender:any,
    maritalStatus:any,
    child:any,
    kids:any,
    profession:any
}