export interface Igoal{
    goalId:number,
    goal:string,
}